﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFEmployeeApp
{
    class Class1
    {
        static void Main()
        {
            using(EMPZENSAREntities db = new EMPZENSAREntities())
            {
                var emp = db.SalaryInfoes.Include("EmpMaster").ToList();
                foreach(var t in emp)
                {
                    Console.WriteLine($"{t.EmpCode}\t\t{t.Basic}\t\t{t.NetSalary}\t\t{t.EmpMaster.EmpName}");
                }
                Console.ReadLine();
            }
        }
    }
}
