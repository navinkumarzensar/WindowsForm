﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EFEmployeeApp.BLL;

namespace EFEmployeeApp
{
    class Program
    {
        static void Main(string[] args)
        {
            EmpMasterBLL ebll = new EmpMasterBLL();
            Console.WriteLine("1.)Save\n2.)Delete\n3.)Update\n4.)View\n5.)View All\n6.)EXIT\nEnter Your Choice : ");
            int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        EmpMaster e = new EmpMaster() { EmpCode = 1000, EmpName = "Vijaya", EmpDob = Convert.ToDateTime("1995-01-02"), EmpGender = "Female", EmpDepartment = "SALES", EmpDesignation = "MANAGER" };
                        if (ebll.SaveEmployee(e))
                        {
                            Console.WriteLine("Employee Record Saved...");
                        }
                        else
                        {
                            Console.WriteLine("Error Occured....");
                        }
                        break;
                    case 2:
                        if (ebll.DeleteEmployee())
                        {
                            Console.WriteLine("Employee Record Deleted...");
                        }
                        else
                        {
                            Console.WriteLine("Error Occured....");
                        }
                        break;
                    case 3:
                        EmpMaster e1 = new EmpMaster() { EmpCode = 3, EmpDepartment = "HR", EmpDesignation = "ASSISTANT" };
                        if (ebll.UpdateEmployee(e1))
                        {
                            Console.WriteLine("Employee Record Updated...");
                        }
                        else
                        {
                            Console.WriteLine("Error Occured....");
                        }
                        break;
                    case 4:
                        ViewEmployee_Result e2 = ebll.ViewEmp(3);
                        if (e2 != null)
                        {
                            Console.WriteLine($"{e2.EmpCode}\t\t{e2.EmpName}\t\t{e2.EmpGender}\t\t{e2.EmpDepartment}\t\t{e2.EmpDesignation}");
                        }
                        else
                        {
                            Console.WriteLine("Error Occured....");
                        }
                        break;
                    case 5:
                        List<EmpMaster> elist = ebll.ViewAllEmployees();
                        foreach (var t in elist)
                        {
                            Console.WriteLine($"{t.EmpCode}\t\t{t.EmpName}\t\t{t.EmpGender}\t\t{t.EmpDepartment}\t\t{t.EmpDesignation}");
                        }
                        break;
                    default: Console.WriteLine("Invalid Input..."); break;
                }
            Console.ReadLine();
        }
    }
}
