﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFEmployeeApp.BLL
{
    class EmpMasterBLL
    {
        public bool SaveEmployee(EmpMaster e)
        {
            using(EMPZENSAREntities dbcontext = new EMPZENSAREntities())
            {
                dbcontext.EmpMasters.Add(e);
                dbcontext.SaveChanges();
            }
            return true;
        }

        public bool DeleteEmployee()
        {
            using (EMPZENSAREntities dbcontext = new EMPZENSAREntities())
            {
                //var v = dbcontext.EmpMasters.First();
                //var v = dbcontext.EmpMasters.Find(1000);
                var v = dbcontext.EmpMasters.First(s => s.EmpCode == 1000);
                dbcontext.EmpMasters.Remove(v);
                dbcontext.SaveChanges();
            }
            return true;
        }

        public bool UpdateEmployee(EmpMaster e)
        {
            using (EMPZENSAREntities dbcontext = new EMPZENSAREntities())
            {
                var s = dbcontext.EmpMasters.Find(e.EmpCode);
                s.EmpDepartment = e.EmpDepartment;
                s.EmpDesignation = e.EmpDesignation;
                dbcontext.SaveChanges();
            }
            return true;
        }

        //public EmpMaster ViewEmployee(int eid)
        //{
        //    EmpMaster emp = new EmpMaster();
        //    using(EMPZENSAREntities db = new EMPZENSAREntities())
        //    {
        //        var s = db.EmpMasters.Where(x => x.EmpCode == eid).First();
        //        emp = s;
        //    }
        //    return emp;
        //}

        public ViewEmployee_Result ViewEmp(int eid)
        {
            ViewEmployee_Result ve = new ViewEmployee_Result();
            using(EMPZENSAREntities db = new EMPZENSAREntities())
            {
                var v = db.ViewEmployee(eid).First();
                ve = v;
            }
            return ve;
        }
        
        public List<EmpMaster> ViewAllEmployees()
        {
            List<EmpMaster> elist = new List<EmpMaster>();
            using(EMPZENSAREntities db = new EMPZENSAREntities())
            {
                var s = db.EmpMasters.ToList();
                elist = s;
            }
            return elist;
        }
    }
}
