﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsForm1
{
    public partial class formDataBinding1 : Form
    {
        SqlConnection sqlcon = new SqlConnection(WindowsForm1.Properties.Settings.Default.ConStr);
        SqlDataAdapter da;
        DataSet ds = new DataSet();
        public formDataBinding1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                ds.Reset();
                da = new SqlDataAdapter("select DISTINCT(EmpDepartment) from DepartmentMaster", sqlcon);
                da.Fill(ds, "Dept");
                comboBox1.DataSource = ds.Tables["Dept"];
                comboBox1.ValueMember = "EmpDepartment";
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DataSet ds1 = new DataSet();
            try
            {
                ds1.Reset();
                da = new SqlDataAdapter("Select * from EmpMaster where EmpDepartment = '"+comboBox1.Text+"'", sqlcon);
                da.Fill(ds1, "Emp");
                dataGridView1.DataSource = ds1.Tables["Emp"];
            }
            catch (Exception ex)
            {

            }
        }
    }
}
